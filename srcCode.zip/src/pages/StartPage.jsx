import StartTemplate from "../components/templates/StartTemplate";


const StartPage = () => {

    return (
        <>
            <StartTemplate />
        </>
    )
}

export default StartPage;